browser.devtools.panels.create(
  "Open Graph Previewer",
  "../icons/eye.png",
  "../devtools/panel/panel.html"
);
